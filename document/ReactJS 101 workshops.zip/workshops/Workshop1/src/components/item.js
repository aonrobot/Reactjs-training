import React from 'react';

class Item extends React.Component{
    onRemove = () =>{
        // onRemove is callback function from ListItems
        this.props.onRemove(this.props.id);
    }
    render(){
        return(
            <div className="card__item">
                <h3>Title : {this.props.title}</h3>
                <p>Number : {this.props.number}</p>
                <p>Type : {this.props.type}</p>
                <button className="button button__remove" onClick={this.onRemove}>Remove</button>
            </div>
        )
    }
}

export default Item;