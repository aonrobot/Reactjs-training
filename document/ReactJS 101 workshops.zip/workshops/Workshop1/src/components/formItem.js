import React from 'react';

class FormItem extends React.Component{
    submit = (e:Event)=>{
        // stop default event
        e.preventDefault();
        let title = e.target.title.value;
        let number = e.target.number.value;
        if(number && title){
            // check type income or expense
            let type = "income";
            if(number < 0){
               type = "expense"; 
            }
            // onSubmit is callback function from App
            this.props.onSubmit({title,number,type});
            this.clear();
        }   
    }
    clear = () =>{
        // clear all input in form
        this.form.reset();
    }
    render(){
        return(
            <div>
                <h2 className="create__input_head">Enter List</h2>
                <form onSubmit={this.submit} ref={(el)=>this.form = el}>
                    <input className="create__input create__input_title" autoComplete="off" placeholder="Enter title" name="title" type="text" />
                    <input className="create__input create__input_number" autoComplete="off" placeholder="Enter number" name="number" type="number" />
                    <br/>
                    <button className="button button__create">Create</button>
                    <button className="button button__clear" onClick={this.clear}>Clear</button>
                </form>
            </div>
        )
    }
}

export default FormItem;