import React from 'react';
import FormItem from './components/formItem';
import ListItems from './components/listItems';

// custom style
import './styles.css';
// reset style default 
import 'normalize.css';

class App extends React.Component {
  // default state
  state = {
    items:[],
    total:0
  }

  submit = (item) =>{
    // Add item in array send by FormItem
    this.setState((state)=>{
      let items = state.items.concat([item]);
      return{
        items,
        total:this.updateTotal(items)
      }
    })
  }
  onRemove = (key) =>{
    // Remove item in array send index by ListItem
    this.setState((state)=>{
      let items = state.items.filter((item,i)=>i !== key);
      return{
        items,
        total:this.updateTotal(items)
      }
    });
  }
  updateTotal = (array)=>{
    // Update total sum all number
    if(array.length){
      return array.map(item=>item.number).reduce((item,total)=>{
        return Number(item)+Number(total)
      });
    }
    return 0;
  }

  render() {
    return (
      <div className="block">
        <FormItem onSubmit={this.submit}/>
        <ListItems items={this.state.items} total={this.state.total} onRemove={this.onRemove} />
      </div>
    );
  }
}

export default App;
