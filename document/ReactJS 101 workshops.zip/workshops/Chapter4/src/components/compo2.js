import React from 'react' ;
// function component
const Compo2 = ()=>{
    return ( <div>hello func component</div> ); 
}
export default Compo2;
