import React from 'react' ;
// class component
class Compo1 extends React.Component{
    render(){
     return ( <div>hello class component</div> ); 
    }
}
export default Compo1;
