import React from 'react' ;
import FormItem from './components/formItem' ;
class App extends React.Component{
  render(){
      return (
        <div>              
          <FormItem />       
        </div>
      ); 
  } 
}
export default App;
