import React from 'react' ;
import Compo1 from './components/compo1' ;
import Button1 from './components/button1';

class App extends React.Component{
    render(){
      return (<div>         
        <Compo1 title="this is title"/>
        <Compo1 title="hello world"/> 
        <Button1 />      
      </div>); 
      } 
    }
export default App;
