import React from 'react' ;
import { Switch,Route } from 'react-router';
import HomePage from './pages/homepage';
import AboutPage from './pages/aboutpage';
import DetailPage from './pages/detailpage';
import NotfoundPage from './pages/notfoundpage';

import Header from './components/header';

const Router = ()=>{
    return (
        <div>
            <Header />
            <Switch>
                <Route component={HomePage}  path="/" exact />        
                <Route component={AboutPage} path="/about" />
                <Route component={DetailPage} path="/detail/:id" />
                <Route component={NotfoundPage} path="*" />
            </Switch>   
        </div>
    ) 
} 
export default Router;
