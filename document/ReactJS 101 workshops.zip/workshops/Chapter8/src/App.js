import React from 'react'; import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import  Router  from './Router';
import { createStore } from 'redux';
import reducerCounter from './reducers/counter';

// create store
const store = createStore(reducerCounter);

class App extends React.Component{
    render(){ 
        return ( 
          <Provider store={store}>
	            <BrowserRouter>
	                <Router />
        	    </BrowserRouter>
          </Provider> 
        ); 
    }
} 
export default App;
