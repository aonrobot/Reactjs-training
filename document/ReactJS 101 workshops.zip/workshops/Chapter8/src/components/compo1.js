import React from 'react' ;

// class component

class Compo1 extends React.Component{
     render(){
         return ( <div>{this.props.title}</div> ); 
     }
}
export default Compo1;
