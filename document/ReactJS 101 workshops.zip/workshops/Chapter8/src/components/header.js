import React from 'react' ;
import { Link } from 'react-router-dom';

// function component

const Header = () =>{
        return (<ul>
         <Link to="/">home</Link>
         <Link to="/about">AboutUs</Link>       
        </ul>); 
}
export default Header;
