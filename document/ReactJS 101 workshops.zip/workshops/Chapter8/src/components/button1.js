import React from 'react' ;

// class component

class Button1 extends React.Component{
   // set default state
   state = { text:"button" };
   func1 = () =>{
    // when click event change state text
    this.setState({ text:"clicked" });
   }
   render(){
     return (<div>      
        <button onClick={this.func1}>{ this.state.text }</button> 
      </div>); 
    }
}
export default Button1;
