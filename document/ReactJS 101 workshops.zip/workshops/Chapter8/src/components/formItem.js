import React from 'react' ;
class FormItem extends React.Component{
    submit = (e:Event) =>{
        // stop default event
        e.preventDefault();
        console.log(e.target.input1.value);
        console.log(e.target.input2.value);
    }
    clear = () => {
        // clear all input
        this.form.reset();
    }
     
    render(){
     return ( 
        <form onSubmit={this.submit} ref={(el)=>{ this.form = el} }>         
            <input name="input1" />
            <input name="input2" />
            <button type="submit">submit</button>
            <button type="button" onClick={this.clear}>clear</button>        
        </form> ); 
    }
}
export default FormItem;
