import React from 'react' ;

// function component
// receive props 'name' title

const Compo2 = ({title})=>{
    return ( <div>{title}</div> ); 
}
export default Compo2;
