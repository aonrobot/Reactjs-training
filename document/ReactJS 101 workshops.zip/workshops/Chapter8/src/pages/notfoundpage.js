import React from 'react';

// page component

class NotfoundPage extends React.Component{
   render(){
     return ( <div>notfound 404</div> ); 
   }
}
export default NotfoundPage;
