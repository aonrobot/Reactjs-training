import React from 'react';import { connect } from 'react-redux';
import { couterIncrease,couterDecrease } from '../actions/counter';

class HomePage extends React.Component{
    render(){ 
       return (<div>
           <button onClick={this.props.increase}>+</button>
           <button onClick={this.props.decrease}>-</button>
           {this.props.count}
        </div> ); 
    }  
}

const mapStateToProps = (state,props)=>{
    return{ count:state.count } 
}
const mapDispatchToProps = (dispatch)=>{
    return{   
            increase:()=>dispatch(couterIncrease()),
            decrease:()=>dispatch(couterDecrease())         
    } 
}
export default connect (mapStateToProps,mapDispatchToProps)(HomePage);

 
  