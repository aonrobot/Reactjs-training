import React from 'react' ;

// page component

class AboutPage extends React.Component{
   render(){
        return ( <div>hello about page</div> ); 
   }
}
export default AboutPage;
