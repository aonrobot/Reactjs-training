export const INCREASE = "increase";
export const DECREASE = "decrease";

// function for increase counter
export const couterIncrease = ()=>{
    return { 
          type:INCREASE 
    }
}
// function for decrease counter
export const couterDecrease = ()=>{
    return { 
          type:DECREASE 
    }
}
