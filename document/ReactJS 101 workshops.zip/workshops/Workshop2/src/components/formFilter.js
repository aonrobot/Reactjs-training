import React from 'react';
import { filterTitle,filterType } from '../actions/items';
import { connect } from 'react-redux';

class FormFilter extends React.Component{
    selectChange = (e:Event)=>{
        // dispatch filter type
        this.props.filterType(e.target.value);
    }
    inputChange = (e:Event)=>{
        // dispatch filter title
        this.props.filterTitle(e.target.value);
    }
    render(){
        return(
            <div className="card card__item">
                <input onChange={this.inputChange} className="filter__input" placeholder="Enter title" />
                <select onChange={this.selectChange} className="filter__input filter__input_select">
                    <option>all</option>
                    <option>income</option>
                    <option>expense</option>
                </select>
            </div>
        )
    }
}
const mapDispatchToProps = (dispatch)=>{
    return{
        filterTitle:(title)=>{ dispatch(filterTitle(title))},
        filterType:(type)=>{ dispatch(filterType(type)) }
    }
}
export default connect(null,mapDispatchToProps)(FormFilter);
