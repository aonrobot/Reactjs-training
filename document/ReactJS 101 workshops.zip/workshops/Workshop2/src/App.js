import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import Router from './Router';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import reducerItems from './reducers/items';

// custom style
import './styles.css';
// reset style default 
import 'normalize.css';

// create store
const store = createStore(reducerItems);

store.subscribe(()=>{
  // uncomment for debug dispatch
  // console.log(store.getState());
});

class App extends React.Component {
  render() {
    return (
      <Provider store={store}>
        <BrowserRouter>
          <Router />
        </BrowserRouter>
      </Provider>
    );
  }
}

export default App;
