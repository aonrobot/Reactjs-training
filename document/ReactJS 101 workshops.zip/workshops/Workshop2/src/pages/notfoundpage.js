import React from 'react';

class NotfoundPage extends React.Component{
    render(){
        return(
            <div className="block">
                <div className="card card__item">
                    <h1>Not found 404</h1>
                </div>
            </div>
        )
    }
}
export default NotfoundPage;