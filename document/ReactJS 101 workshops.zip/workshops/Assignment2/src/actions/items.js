import moment from 'moment';

//Action Const
export const PUSH_ITEM = "push_item";
export const REMOVE_ITEM = "remove_item";
export const EDIT_ITEM = "edit_item";
export const FILTER_TITLE = "filter_title";
export const FILTER_TYPE = "filter_type";
export const FILTER_LIMIT = "filter_limit";
export const FILTER_DATE = "filter_date";
export const CHANGE_PAGE = "change_page";


//Date Const
const day = moment().startOf('day');
const week = moment().subtract(1,'week').startOf('day');
const month = moment().subtract(1,'month').startOf('day');
const year = moment().subtract(1,'year').startOf('day');

export const pushItem = (item)=>{
    return{ type:PUSH_ITEM,item }
};

export const removeItem = (id)=>{
    return{ type:REMOVE_ITEM,id }
};
export const editItem = (item)=>{
    return{ type:EDIT_ITEM,item }
};
export const filterTitle = (title)=>{
    return{ type:FILTER_TITLE,title }
}
export const filterType = (type)=>{
    return{ type:FILTER_TYPE,typeFilter:type }
}
export const filterLimit = (limit)=>{
    return{ type:FILTER_LIMIT,limit }
}
export const filterDate = (date)=>{
    return{ type:FILTER_DATE,date }
}
export const changePage = (page)=>{
    return{ type:CHANGE_PAGE,page }
}

export const getItemById = (state,id)=>{
    return state.items.find((item)=>item.id == id);
}

export const filterItem = (items,filter)=>{
    // filter type
    if(filter.type && filter.type != "all"){
        items = items.filter(item=>item.type == filter.type);
    }
    // search title item
    if(filter.title){
        items = items.filter(item=>item.title.indexOf(filter.title) > -1)
    }
    // sort array created desc
    items.sort((a,b)=>b.created-a.created);
    if(filter.date && filter.date != "all"){
        switch(filter.date){
            case "day":
                items = items.filter(item=>moment(item.created).isAfter(day));
                break;
            case "week":
                items = items.filter(item=>moment(item.created).isAfter(week));
                break;
            case "month":
                items = items.filter(item=>moment(item.created).isAfter(month));
                break;
            case "year":
                items = items.filter(item=>moment(item.created).isAfter(year));
                break;
        }
    }
    return items;
}