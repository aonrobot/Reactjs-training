import React from 'react';
import Item from './item';
import { connect } from 'react-redux';
import { changePage } from '../actions/items';

// function component
const Paginator = ({items,filter,onChangePage})=>{
    if(items.length <= filter.limit){
        return false;
    }
    // Math ceil is round up number after divide
    let size = Math.ceil(items.length / filter.limit);
    // Array from is add item from size and define default value
    let array = Array.from({length:size},(x,i)=>i);
    return(
        <div>
            {
              array.map((item,index)=>{
                if(filter.page === index+1){
                    return(
                        <button className="button button__pagination_active" onClick={()=>{onChangePage(index+1)}} key={index}>{index+1}</button>
                    )
                }else{
                    return(
                        <button className="button button__pagination" onClick={()=>{onChangePage(index+1)}} key={index}>{index+1}</button>
                    )
                }
              })
            }
        </div>
    )
};

class ListItems extends React.Component{
    render(){ 
        let items = [];
        let limit = this.props.filter.limit;
        let page = this.props.filter.page;
        if(this.props.filter.page == 1){
            // when page = 1
            items = this.props.items.slice(0,limit);
        }else{
            // when page > 1
            let start = (page-1) * limit;
            items = this.props.items.slice(start,start+limit);
        }
        return(
            <div>{ 
                   this.props.items.length?
                   <div>    
                    <ul className="card">
                        <h1 className="card__head">Total : {this.props.total}</h1>
                           {   
                                items.map((item,index)=>{
                                    return( 
                                    <Item key={index} {...item} />
                                    )
                                }) 
                           }
                    </ul>
                    <Paginator onChangePage={this.props.changePage} items={this.props.items} filter={this.props.filter}  />
                   </div>
                   : <div className="card card__item">not have item</div>
            }</div>
        )
    }
}
const mapDispatchToProps = (dispatch)=>{
    return{
        changePage:(page)=>dispatch(changePage(page))
    }
}
export default connect(null,mapDispatchToProps)(ListItems);