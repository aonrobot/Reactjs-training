import React from 'react';
import { filterTitle,filterType,filterLimit,filterDate } from '../actions/items';
import { connect } from 'react-redux';

class FormFilter extends React.Component{
    selectTypeChange = (e:Event)=>{
        // dispatch filter type
        this.props.filterType(e.target.value);
    }
    selectLimitChange = (e:Event)=>{
        // dispatch filter limit
        this.props.filterLimit(e.target.value);
    }
    selectDateChange = (e:Event)=>{
        // dispatch filter date
        this.props.filterDate(e.target.value);
    }
    inputChange = (e:Event)=>{
        // dispatch filter title
        this.props.filterTitle(e.target.value);
    }
    render(){
        return(
            <div className="card card__item">
                <input defaultValue={this.props.filter.title} onChange={this.inputChange} className="filter__input" placeholder="Enter title" />
                <select defaultValue={this.props.filter.type} onChange={this.selectTypeChange} className="filter__input filter__input_select">
                    <option>all</option>
                    <option>income</option>
                    <option>expense</option>
                </select>
                <select defaultValue={this.props.filter.date} onChange={this.selectDateChange} className="filter__input filter__input_select">
                    <option value="all">all</option>
                    <option value="day">today</option>
                    <option value="week">1 week</option>
                    <option value="month">1 month</option>
                    <option value="year">1 year</option>
                </select>
                <select defaultValue={this.props.filter.limit} onChange={this.selectLimitChange} className="filter__input filter__input_select">
                    <option value="3">3 item</option>
                    <option value="5">5 item</option>
                    <option value="10">10 item</option>
                </select>
            </div>
        )
    }
}
const mapStateToProps = (state,props)=>{
    return{
        filter:state.filter
    }
}
const mapDispatchToProps = (dispatch)=>{
    return{
        filterTitle:(title)=>{ dispatch(filterTitle(title))},
        filterType:(type)=>{ dispatch(filterType(type)) },
        filterLimit:(limit)=>{ dispatch(filterLimit(limit))},
        filterDate:(date)=>{ dispatch(filterDate(date))}
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(FormFilter);
