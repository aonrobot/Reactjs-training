import React from 'react';
import ListItems from '../components/listItems';
import { connect } from 'react-redux';
import { filterItem } from '../actions/items';
import FormFilter from '../components/formFilter';

class HomePage extends React.Component{
    render(){
        return(
            <div className="block">
                <FormFilter />
                <ListItems filter={this.props.filter} items={this.props.items} total={this.props.total} onRemove={this.onRemove} />
            </div>
        )
    }
}
const mapStateToProps = (state,props)=>{
    return{
        // filter items before use
        items:filterItem(state.items,state.filter),
        filter:state.filter,
        total:state.total
    }
};
export default connect(mapStateToProps)(HomePage);