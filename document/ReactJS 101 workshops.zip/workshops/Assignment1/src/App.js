import React from 'react';
import FormInput from './components/formInput';
import ButtonsOperator from './components/buttonsOperator';
import ScreenResult from './components/screenResult';

// custom style
import './styles.css';
// reset style default 
import 'normalize.css';



class App extends React.Component {
  // default state
  state = {
    input1:0,input2:0,operator:"",result:0
  }

  onSelectOperator = (value)=>{
    // setState operator
    this.setState((state)=>{
      return{ ...state,operator:value}
    });
  }
  onInputChange = (name,value)=>{
    // setState input
    if(name === "input1"){
      this.setState((state)=>{
        return{ ...state,input1:value}
      });
    }else if(name === "input2"){
      this.setState((state)=>{
        return{ ...state,input2:value}
      });
    }
  }
  calulate = ()=>{
    // check if input1 and input2 have value
    if(this.state.input1 && this.state.input2){
      switch(this.state.operator){
        case "plus":
          this.setState((state)=>{
            return{
              ...state,
              result:Number(state.input1)+Number(state.input2)
            }
          });
          break;
        case "minus":
          this.setState((state)=>{
            return{
              ...state,
              result:Number(state.input1)-Number(state.input2)
            }
          });
          break;
        case "multiply":
          this.setState((state)=>{
            return{
              ...state,
              result:Number(state.input1)*Number(state.input2)
            }
          });
          break;
        case "divide":
          this.setState((state)=>{
            return{
              ...state,
              result:(this.state.input1 / this.state.input2).toFixed(3)
            }
          });
          break;
        default:
      }
    }
  }
  clear = ()=>{
    // setState to default for clear
    this.setState({
        input1:0,input2:0,operator:"",result:0
    })
  }
  render() {
    return (
      <div className="block">
        <div className="card">
          <ScreenResult result={this.state.result} />
        </div>
        <div className="card">
          <FormInput onInputChange={this.onInputChange} {...this.state} />
        </div>
        <div className="card">
          <ButtonsOperator onSelectOperator={this.onSelectOperator} operator={this.state.operator} />
        </div>
        <button className="button button__calculate" onClick={this.calulate}>Calulate!</button>
        <button className="button button__clear" onClick={this.clear}>Clear</button>
      </div>
    );
  }
}

export default App;
