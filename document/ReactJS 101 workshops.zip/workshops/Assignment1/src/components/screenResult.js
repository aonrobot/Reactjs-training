import React from 'react';

const ScreenResult = ({ result })=>{
        return(
            <div className="card__item">
                <h1>Result : {result}</h1>
            </div>
        )
}
export default ScreenResult;