import React from 'react';

class ButtonsOperator extends React.Component{
    selectOperator = (e:Events)=>{
        // onSelectOperator is callback function from App
        this.props.onSelectOperator(e.target.value);
    }
    checkedOperator = (operator)=>{
        // check operator
        if(operator === this.props.operator){
            return true;
        }
        return false;
    }  
    render(){
        return(
            <div className="card__item card__radio_group">
                    <div className="radio__item">
                        <label>+</label>
                        <input checked={this.checkedOperator('plus')} onChange={this.selectOperator} type="radio" name="operator" value="plus" />
                    </div>
                    <div className="radio__item">
                        <label>-</label>
                        <input checked={this.checkedOperator('minus')} onChange={this.selectOperator} type="radio" name="operator" value="minus" />
                    </div>
                    <div className="radio__item">
                        <label>x</label>
                        <input checked={this.checkedOperator('multiply')} onChange={this.selectOperator} type="radio" name="operator" value="multiply" />
                    </div>
                    <div className="radio__item">
                        <label>/</label>
                        <input checked={this.checkedOperator('divide')} onChange={this.selectOperator} type="radio" name="operator" value="divide" />
                    </div>
            </div>
        )
    }
}
export default ButtonsOperator;