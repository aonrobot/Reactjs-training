import React from 'react';

class ButtonsOperator extends React.Component{
    inputChange = (e:Event)=>{
       // onInputChange is callback function from App
       this.props.onInputChange(e.target.name,e.target.value);
    }
    render(){
        return(
            <div className="card__item card__input">
                <div>
                    <label>input 1 :</label>
                    <input className="input" value={this.props.input1} onChange={this.inputChange} name="input1" type="number" />
                </div>
                <div>
                    <label>input 2 :</label>
                    <input className="input" value={this.props.input2} onChange={this.inputChange} name="input2" type="number" />
                </div>
            </div>
        )
    }
}
export default ButtonsOperator;