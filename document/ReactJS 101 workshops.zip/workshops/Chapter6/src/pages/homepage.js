import React from 'react' ;

// page component

class HomePage extends React.Component{
   render(){
     return ( <div>hello home page</div> ); 
   }
}
export default HomePage;
