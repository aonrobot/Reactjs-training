import { createStore } from 'redux';
const defaultState = { count : 0 }

// reducer is store function for change state in redux-store

const reducer = (state=defaultState,action)=>{
    switch(action.type){
        case 'increase':
           return { count:state.count + 1 };      
        case 'decrease':
           return { count:state.count - 1 };
    } 
}


const store = createStore(reducer);
store.subscribe(()=>{ 
    console.log(store.getState()) 
});
store.dispatch({type:'increase'});
store.dispatch({type:'decrease'});

